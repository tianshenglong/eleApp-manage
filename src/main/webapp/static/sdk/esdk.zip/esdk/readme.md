#ESDK 接入文档

- 先把资源放在项目对应的文件夹中

- 权限配置：
	
	```
	<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.READ_PHONE_STATE" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
<uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.GET_TASKS" />
<uses-permission android:name="android.permission.READ_LOGS" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
	```

- 组件注册
```
<!— AppID —>
<meta-data android:name="ESDK_APPID" android:value="填写自己申请的appid"/>
<!— AppKEY —>
<meta-data android:name="ESDK_APPKEY" android:value="填写自己申请的appkey"/>
<activity android:name="me.kims.elephant.authorize.ui.AuthorizeActivity"
            android:configChanges="keyboardHidden|orientation|screenSize"  
	android:screenOrientation="portrait" 
            ></activity>
```

- 接口说明
- SDK 初始化（必接）
	- 接口
	`public static void initSdk(Activity mAct,onESdkCallback mCallback){}`

	- 示例：
	```
	ESdkApi.init(MainActivity.this, new onESdkCallback() {
			
			@Override
			public void onSuccess(int code,String msg) {
				Toast.makeText(MainActivity.this, "init "+msg, 0).show();
			}
			
			@Override
			public void onFailed(int code,String msg) {
				// TODO Auto-generated method stub
				Toast.makeText(MainActivity.this, "init "+msg, 0).show();
			}
		});
	```
	- 

- SDK 授权（必接）
- 接口
	`public static void authorize(Activity activity){}`

	- 示例：
	```
	ESdkApi.authorize(this);
	
		@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

			String msg = data.getStringExtra("result");
			System.out.println("-------"+msg);
			try {
				JSONObject js = new JSONObject(msg);
			String code = js.optString("resultCode");
			String resultMsg = js.optString("msg");
			System.out.println("我是获取到返回的Code："+code);
			System.out.println("我是获取到返回的数据："+resultMsg);
			Toast.makeText(this, ""+resultMsg, 0).show();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
	}
	```

- SDK log打印 （测试使用）
	- 示例
	`ESdkApi.setSdkLog(true)` // 开启log输出
	`ESdkApi.setSdkLog(false)` // 关闭log输出
	
